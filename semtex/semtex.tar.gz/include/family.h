#ifndef FAMILY_H
#define FAMILY_H

namespace Family {
  void abandon (real**);
  void adopt   (const integer, real**);
}

#endif
